package application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class FormularioController {

	String password = "123456";
	public PasswordField inputpassword;
	public void iniciarsesion() {
		if(inputpassword.getText().equals(password)) {
			try {
				GridPane root = (GridPane)FXMLLoader.load(getClass().getResource("Prueba.fxml"));
				Scene scene = new Scene(root,261,311);
				Stage pruebaStage = new Stage();
				pruebaStage.setScene(scene);
				pruebaStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}else {
			System.out.println("CONTRASE�A ERR�NEA");
		}
	}
}
